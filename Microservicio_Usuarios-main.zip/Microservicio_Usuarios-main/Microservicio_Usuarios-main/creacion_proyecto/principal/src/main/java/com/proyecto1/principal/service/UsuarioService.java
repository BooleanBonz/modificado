package com.proyecto1.principal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto1.principal.model.Usuario;
import com.proyecto1.principal.model.entity.UsuarioEntity;
import com.proyecto1.principal.repository.UsuarioRepository;

@Service

public class UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    public String crearUsuario(Usuario usuario){
        
        try{
            Boolean estado = usuarioRepository.existsByCorreo(usuario.getCorreo());
            if (!estado){
                UsuarioEntity usuarioNuevo = new UsuarioEntity();
                    usuarioNuevo.setIdUsuario(usuario.getIdUsuario());
                    usuarioNuevo.setNombre(usuario.getNombre());
                    usuarioNuevo.setApellidos(usuario.getApellidos());
                    usuarioNuevo.setCorreo(usuario.getCorreo());
                    usuarioNuevo.setContrasena(usuario.getContrasena());
                    usuarioRepository.save(usuarioNuevo);
                    return "Usuario creado correctamente";
                }    
                return "el correo ya existe";
                } 
        catch (Exception e) {
            return "Error al crear el usuario" +e.getMessage();
        }

        }

    public Usuario obteneUsuario(String correo){
        try{
            UsuarioEntity usuario = usuarioRepository.findByCorreo(correo);
            if (usuario != null){
                Usuario user = new Usuario(
                    usuario.getIdUsuario(),
                    usuario.getNombre(),
                    usuario.getApellidos(),
                    usuario.getCorreo(),
                    usuario.getContrasena()
                );
                return user;
            }
            return null;
        }catch (Exception e) {
            return null;
        }
    }

}



